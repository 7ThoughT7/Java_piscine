INSERT INTO users(email) VALUES ('kit@mail.ru');
INSERT INTO users(email) VALUES ('alloha@mail.ru');
INSERT INTO users(email) VALUES ('kapibara@gmail.com');
CREATE TABLE users (
    identity BIGSERIAL PRIMARY KEY,
    email VARCHAR(20)
);
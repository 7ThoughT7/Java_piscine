package edu.school21;

public interface Render {
    void printText(String text);
}

package edu.school21;

public interface Printer {
    void print(String text);
}

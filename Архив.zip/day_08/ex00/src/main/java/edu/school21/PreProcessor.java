package edu.school21;

public interface PreProcessor {
    String preProcess(String text);
}

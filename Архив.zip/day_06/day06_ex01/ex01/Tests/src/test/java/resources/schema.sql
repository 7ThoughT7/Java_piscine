CREATE TABLE product_tables
(
    identiﬁer  INT,
    name VARCHAR(20),
    price INT
);
INSERT INTO product_tables(identiﬁer, name, price) VALUES (1, 'aaa', 10);
INSERT INTO product_tables(identiﬁer, name, price) VALUES (2, 'bbb', 20);
INSERT INTO product_tables(identiﬁer, name, price) VALUES (3, 'ccc', 30);
INSERT INTO product_tables(identiﬁer, name, price) VALUES (4, 'ddd', 40);
INSERT INTO product_tables(identiﬁer, name, price) VALUES (5, 'eee', 50);
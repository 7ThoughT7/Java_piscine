package ex02;

public enum TransferCategory {
    DEBITS,
    CREDITS,
}

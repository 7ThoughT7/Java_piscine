package ex03;

public enum TransferCategory {
    DEBITS,
    CREDITS,
}
